<script>
	let current = 'green';
</script>

<style>
	div {
		display: block;
        width: 100px;
        height: 100px;
	}

	.active {
		
		color: white;
        display: none;
	}
.green{background: green;}
.red{  background: red;}
.blue{background: blue;}
</style>

<div
	class=" green {current === 'green' ? 'active' : ''}"
	on:click="{() => current = 'green'}"
></div>

<div
	class=" red {current === 'red' ? 'active' : ''}"
	on:click="{() => current = 'red'}"
></div>

<div
	class="blue {current === 'blue' ? 'active' : ''}"
	on:click="{() => current = 'blue'}"
></div>