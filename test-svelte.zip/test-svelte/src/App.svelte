<script>
	import First from './FirstBlock.svelte';

	
	let opacity;
	let color;


	const Active=(e)=>{
	opacity=e.target.value;
}

	const AddColor=(e)=>{
	color=e.target.value;
}
	</script>
<style>


.box{
	width: 100px;
	height: 100px;
	border: 1px black solid;

}
input {
	margin: 15px;
}

</style>


	

<div class="box" style="background:{color};opacity:{opacity}" id="box"></div>
<input type="color" bind:value="{color}">
<input type="text" bind:value="{opacity}"> <p>Введите число от 0 до 1(Например 0,5)</p>


<hr>

<First/>