import App from './App.svelte';
import First from './FirstBlock.svelte';
	
const app = new App({
	target: document.body,
	props: {
		name: 'worsvelrld'
	}
});

export default app;